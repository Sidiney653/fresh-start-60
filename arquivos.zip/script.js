// CARROSSEL DE MAPAS

const slides = [...document.querySelectorAll('.preview')];
const dots = [...document.querySelectorAll('.dots button')];

let current = 0;

function showSlide(n) {
  current = (n + slides.length) % slides.length;

  slides.forEach((slide, i) => {
    slide.classList.toggle('active', i === current);
  });

  dots.forEach((dot, i) => {
    dot.classList.toggle('on', i === current);
  });
}

document.querySelector('.prev')
  .addEventListener('click', () => showSlide(current - 1));

document.querySelector('.next')
  .addEventListener('click', () => showSlide(current + 1));

dots.forEach((dot, i) => {
  dot.addEventListener('click', () => showSlide(i));
});

// CARROSSEL AUTOMATICO
setInterval(() => {
  showSlide(current + 1);
}, 4500);

// ================= CONFIGURAÇÃO =================
// Edite APENAS este bloco com os dados reais do seu produto.
const CONFIG = {
  checkoutUrl: '',            // link oficial do checkout
  priceFrom: 'R$ 197,00',     // preço "de" (use um valor real e comprovável)
  priceTo: 'R$ 37,90',        // preço "por"
  guaranteeDays: 7,
  offerEnd: '',               // ex.: '2026-11-30' — deixe vazio se não houver prazo real
  company: 'Seu Nome/Empresa', cnpj: '',
  termsUrl: '#', privacyUrl: '#', contactUrl: '#',
  levels: [
    { name: 'A1', title: 'Iniciante', items: ['Alfabeto e números', 'Verbo To Be', 'Pronomes', 'Saudações'] },
    { name: 'A2', title: 'Básico', items: ['Simple Past', 'Rotina e família', 'Preposições', 'Comparativos'] },
    { name: 'B1', title: 'Intermediário', items: ['Present Perfect', 'Modal verbs', 'Futuro', 'Viagens e trabalho'] },
    { name: 'B2', title: 'Intermediário avançado', items: ['Conditionals', 'Voz passiva', 'Reported speech', 'Phrasal verbs'] },
    { name: 'C1', title: 'Avançado', items: ['Inversões', 'Expressões idiomáticas', 'Conectores formais', 'Debates'] },
    { name: 'C2', title: 'Proficiente', items: ['Nuances e ironia', 'Registros formal/informal', 'Persuasão', 'Escrita avançada'] }
  ],
  bonuses: [
    { name: 'Nome do bônus 1', desc: 'Descreva o benefício.', value: 'R$ 47', color: 'pink' },
    { name: 'Nome do bônus 2', desc: 'Descreva o benefício.', value: 'R$ 47', color: 'blue' },
    { name: 'Nome do bônus 3', desc: 'Descreva o benefício.', value: 'R$ 47', color: 'yellow' },
    { name: 'Nome do bônus 4', desc: 'Descreva o benefício.', value: 'R$ 47', color: 'green' },
    { name: 'Nome do bônus 5', desc: 'Descreva o benefício.', value: 'R$ 47', color: 'pink' }
  ],
  mainProduct: { name: 'Kit de Mapas Mentais de Inglês (A1–C2)', value: 'R$ 97' }
};
// =================================================

const $ = (id) => document.getElementById(id);

// Níveis A1–C2
const levelsEl = $('levels');
function showLevel(i) {
  const l = CONFIG.levels[i];
  [...levelsEl.children].forEach((b, j) => b.classList.toggle('selected', i === j));
  $('topic-panel').innerHTML = `<h3>${l.name} · ${l.title}</h3>
    <ul>${l.items.map(x => `<li>${x}</li>`).join('')}</ul>`;
}
CONFIG.levels.forEach((l, i) => {
  const b = document.createElement('button');
  b.className = 'topic'; b.textContent = l.name;
  b.onclick = () => showLevel(i);
  levelsEl.appendChild(b);
});
showLevel(0);

// Bônus
$('bonus-grid').innerHTML = CONFIG.bonuses.map((b, i) => `
  <article class="bonus">
    <div class="bonus-cover ${b.color}">BÔNUS 0${i + 1}</div>
    <div>
      <small>BÔNUS #${i + 1}</small>
      <h3>${b.name}</h3>
      <p>${b.desc}</p>
      <p class="bonus-value"><s>${b.value}</s> <b>GRÁTIS</b></p>
    </div>
  </article>`).join('');

// Lista de valor + preços
const stackItems = [CONFIG.mainProduct, ...CONFIG.bonuses];
$('value-stack').innerHTML = stackItems
  .map(x => `<li>✓ ${x.name} <s>${x.value}</s></li>`).join('');
$('final-list').innerHTML = stackItems.map(x => `<li>✓ ${x.name}</li>`).join('');
$('price-from').textContent = CONFIG.priceFrom;
$('price-to').textContent = CONFIG.priceTo;
document.querySelectorAll('.cfg-guarantee')
  .forEach(el => { el.textContent = CONFIG.guaranteeDays; });

// Prazo da oferta (só aparece se houver data real)
if (CONFIG.offerEnd) {
  const d = new Date(CONFIG.offerEnd + 'T23:59:59');
  $('offer-end').textContent = d.toLocaleDateString('pt-BR');
  $('topbar').hidden = false;
}

// Rodapé
$('legal-line').textContent = CONFIG.company + (CONFIG.cnpj ? ' · CNPJ ' + CONFIG.cnpj : '');
$('link-terms').href = CONFIG.termsUrl;
$('link-privacy').href = CONFIG.privacyUrl;
$('link-contact').href = CONFIG.contactUrl;
$('year').textContent = new Date().getFullYear();

// CHECKOUT
// Coloque aqui o link real do seu checkout.

const CHECKOUT_URL = CONFIG.checkoutUrl;

const checkout = document.getElementById('checkout-btn');

if (CHECKOUT_URL) {
  checkout.href = CHECKOUT_URL;
  checkout.removeAttribute('aria-disabled');
  checkout.textContent = 'QUERO ADQUIRIR AGORA →';
} else {
  checkout.addEventListener('click', (event) => {
    event.preventDefault();
  });
}
